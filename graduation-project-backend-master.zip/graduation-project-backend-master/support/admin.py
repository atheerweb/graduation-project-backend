from django.contrib import admin
from .models import SupportTicket,SupportUser
# Register your models here.
admin.site.register(SupportTicket)
admin.site.register(SupportUser)