from django.db import models
from datetime import datetime
from users.models import User
# Create your models here.


class SupportTicket (models.Model):

    Ticket_id = models.AutoField(primary_key=True)
    status = models.BooleanField(default=False)
    # 1,000 characters is between 142 words and 250 words
    description = models.CharField(max_length=1000)
    date_time = models.DateTimeField(default=datetime.now)
    support_to_user = models.ForeignKey('users.User', on_delete=models.CASCADE)

    def __str__(self):
        return str(self.Ticket_id)
class SupportUser(models.Model):
    user_sup = models.ForeignKey(User, on_delete=models.CASCADE)
    ticket_sup= models.ForeignKey(SupportTicket, on_delete=models.CASCADE)