from django.db import models
from datetime import datetime
from users.models import User
# Create your models here.
class FreelancerTransaction(models.Model):
    freelancer_rel = models.ForeignKey(User,on_delete=models.CASCADE)
    transaction_id = models.CharField(max_length=255)
    transaction_name_f = models.CharField(max_length=255)
    transaction_date_f = models.DateTimeField(default=datetime.now)

class Job(models.Model):
    job_id = models.AutoField(primary_key=True)
    jop_title = models.CharField(max_length=255)
    description = models.CharField(max_length=1000)
    cilent_id =  models.ForeignKey(User, on_delete=models.CASCADE)

class UserApplyJobs(models.Model):
    freelance_id = models.ForeignKey(User, on_delete=models.CASCADE)
    job_id = models.ForeignKey(Job, on_delete=models.CASCADE)